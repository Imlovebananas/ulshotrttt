const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Init DB
const db = new Database("links.db");
db.exec(`
  CREATE TABLE IF NOT EXISTS links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    url TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

app.use(express.json());
app.use(express.static("public"));

// Create short link
app.post("/api/shorten", (req, res) => {
  const { url, slug } = req.body;

  if (!url || !slug) {
    return res.status(400).json({ error: "URL and slug are required" });
  }

  // Validate slug (alphanumeric + hyphens only)
  if (!/^[a-zA-Z0-9-_]+$/.test(slug)) {
    return res.status(400).json({ error: "Slug can only contain letters, numbers, hyphens, and underscores" });
  }

  // Validate URL
  try {
    new URL(url);
  } catch {
    return res.status(400).json({ error: "Invalid URL" });
  }

  try {
    const stmt = db.prepare("INSERT INTO links (slug, url) VALUES (?, ?)");
    stmt.run(slug, url);
    return res.json({ success: true, slug });
  } catch (err) {
    if (err.message.includes("UNIQUE")) {
      return res.status(409).json({ error: "Slug already taken, choose another" });
    }
    return res.status(500).json({ error: "Server error" });
  }
});

// Get all links
app.get("/api/links", (req, res) => {
  const links = db.prepare("SELECT slug, url, created_at FROM links ORDER BY created_at DESC").all();
  res.json(links);
});

// Delete a link
app.delete("/api/links/:slug", (req, res) => {
  const { slug } = req.params;
  db.prepare("DELETE FROM links WHERE slug = ?").run(slug);
  res.json({ success: true });
});

// Redirect
app.get("/:slug", (req, res) => {
  const { slug } = req.params;
  const row = db.prepare("SELECT url FROM links WHERE slug = ?").get(slug);
  if (row) {
    return res.redirect(row.url);
  }
  res.status(404).redirect("/?error=notfound");
});

app.listen(PORT, () => {
  console.log(`URL Shortener running on port ${PORT}`);
});
