# URL Shortener

A personal URL shortener with custom slugs. Built with Node.js, Express, and SQLite.

## Deploy to Railway (Free)

1. Push this folder to a GitHub repo
2. Go to [railway.app](https://railway.app) and sign in with GitHub
3. Click **New Project → Deploy from GitHub repo**
4. Select your repo — Railway will auto-detect and deploy it
5. Once deployed, go to **Settings → Networking → Generate Domain**
6. Your shortener is live! 🎉

## Usage

- Visit your Railway URL to open the dashboard
- Paste any URL + choose a custom slug (e.g. `rickroll`)
- Share `yoursite.railway.app/rickroll` and watch the chaos

## Local Development

```bash
npm install
npm start
```

Then open http://localhost:3000
